const io = require("socket.io");

module.exports = {socketIo: io};
