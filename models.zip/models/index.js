exports.default = {
    User: require('./usersModel'),
    SingleRoom : require('./singleRoomModel'),
    GroupRoom: require('./groupRoomModel'),
    log: require('./logs/log'),
}